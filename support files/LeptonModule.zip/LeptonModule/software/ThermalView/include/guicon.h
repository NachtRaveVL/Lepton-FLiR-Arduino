#ifndef __GUICON_H__
#define __GUICON_H__
void RedirectIOToConsole();
#endif

