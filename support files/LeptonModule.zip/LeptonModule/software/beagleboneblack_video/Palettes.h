#ifndef PALETTES_H
#define PALETTES_H

extern const int colormap_rainbow[];
extern const int colormap_grayscale[];
extern const int colormap_ironblack[];

#endif
